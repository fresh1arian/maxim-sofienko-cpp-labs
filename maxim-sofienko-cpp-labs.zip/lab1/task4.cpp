// Task 4 placeholder
int main(){return 0;}
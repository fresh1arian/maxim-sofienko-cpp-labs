// Task 2 placeholder
int main(){return 0;}
// Task 5 placeholder
int main(){return 0;}
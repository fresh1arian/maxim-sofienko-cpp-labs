// Task 3 placeholder
int main(){return 0;}
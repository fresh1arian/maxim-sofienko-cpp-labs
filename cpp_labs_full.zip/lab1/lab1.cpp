#include <iostream>
using namespace std;
int main() {
    int a,b;
    cout << "Enter two integers: ";
    cin >> a >> b;
    cout << "Sum = " << a+b << endl;
    return 0;
}

# Lab 1
Task 1: Basic arithmetic, rectangle area, memory info.

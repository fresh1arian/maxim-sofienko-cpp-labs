# Lab 5
Task 5: Grade evaluation (0–100).

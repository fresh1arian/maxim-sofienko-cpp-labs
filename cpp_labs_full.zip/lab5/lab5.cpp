#include <iostream>
using namespace std;
int main(){
    int g;
    cin >> g;
    if(g>=90) cout<<"Excellent";
    else if(g>=75) cout<<"Good";
    else if(g>=50) cout<<"Satisfactory";
    else cout<<"Unsatisfactory";
}

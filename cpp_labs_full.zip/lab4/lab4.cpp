#include <iostream>
#include <string>
using namespace std;
int main() {
    int age, salary;
    cin >> age >> salary;
    if(age > 20 && salary > 400 && salary < 1000){
        cout << "We will consider your position\n";
    } else cout << "You are not suitable";
}

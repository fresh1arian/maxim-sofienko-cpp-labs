# Lab 4
Task 4: Age + salary check, input name/surname/position.

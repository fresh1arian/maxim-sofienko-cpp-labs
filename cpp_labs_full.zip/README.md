# C++ Labs Repository

This repository contains 5 laboratory works for learning C++ basics.

Each lab includes:
- Task description
- Algorithms
- Code examples
- Instructions for running

Author: Student

# Lab 3
Task 3: Increment/decrement operations.

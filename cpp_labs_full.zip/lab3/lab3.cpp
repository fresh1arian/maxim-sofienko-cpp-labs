#include <iostream>
using namespace std;
int main(){
    int X;
    cin >> X;
    cout << "Prefix: " << ++X << endl;
}

#include <iostream>
using namespace std;
int main() {
    int x;
    cout << "Enter number: ";
    cin >> x;
    cout << "Remainder mod 7 = " << x % 7;
}

# Lab 2
Task 2: Division remainder, divisibility, even/odd.
